<template>
    <div class="page-index">
        <div @mouseover="showLang" @mouseout="hiddenLang" class="langDown">
            <div>
                <span>{{defaultLang}}</span>
            </div>
            <div class="item-menu" v-if="langShow" v-for="(item, index) in lang.locales" :key="index" @click="onSetLang(index)">
                <span class="menu-text">{{item.text}}</span>
            </div>
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
    data() {
       return {
           langShow: false,
           language: 1,
       }
    },
    computed: {
        ...mapState(['lang']),
        // $lang() { // 这个是必须的，告诉对应的页面
        //     return this.$store.state.lang.lang
        // },
        defaultLang () {
            return this.lang.locales[this.language].text;
        }
    },
    methods : {
        getLang(lang) {
            this.langType = lang.text;
        },
        showLang() {
            this.langShow = true;
        },
        hiddenLang() {
            this.langShow = false;
        },
        onSetLang(index) {
            const lang = this.lang.locales[index].val;
            this.language = index;
            this.$store.dispatch("lang/setLang", lang);
        },
    }
}
</script>

<style>
    .langDown {
        cursor: pointer;
    }
    .item-menu {
        padding: 10px;
        width: 80px;
        border-bottom: 1px solid #f9f9f9;
    }
    .menu-text:hover{
        color: #52cbca;
    }
</style>
