<template>
    <div class="wallet-index">
        <Header></Header>
        <div>
            <span>我这里是个钱包</span>
        </div>
        <div>
            <span>看我能翻译不</span>
        </div>
    </div>
</template>

<script>
import { mapState } from "vuex";
import Header from '~/components/Header';
export default {

  props: {

  },
  components: {
      Header,
  },
  data() {
    return {

    };
  },
  computed: {
        ...mapState(['lang']),
        $lang() { // 这个是必须的，告诉对应的页面
            return this.$store.state.lang.lang
        },
    },
  watch: {

  },
  methods: {

  }
};
</script>
<style>
  .limit-level {

  }
</style>

